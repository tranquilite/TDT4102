#include <iostream>
#include <string>
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include "mySFML.h"

long linesDrawn; // Demonstrates simple statistics of no of function calls

// 1920, 1080 is max windowsize on Lasses laptop, found by running code to display video modes from:
// http://www.sfml-dev.org/documentation/2.0/classsf_1_1VideoMode.php#details
//
sf::RenderWindow* openWindow(DisplaySize ds, const string& displayTitle) {
	sf::RenderWindow *windowPtr;
	if (ds == LARGE)
		windowPtr = new sf::RenderWindow(sf::VideoMode(1920, 1080), displayTitle);
	else if (ds == MEDIUM) // Medium, hope to fit projector screen in room F1 at NTNU
		windowPtr = new sf::RenderWindow(sf::VideoMode(1024, 768), displayTitle);
	else {
		cerr << "ILLEGAL DisplaySize in openWindow"; 
		exit(-1);
	}
	windowPtr->setFramerateLimit(60);
	return windowPtr;
}

void closeDown(sf::RenderWindow* wP) {
	delete wP;
	cout << "\n linesDrawn: " << linesDrawn << endl;
}

void drawLine(int length, int startX, int startY, float direction, sf::Color color, sf::RenderWindow* win) { 
	sf::RectangleShape rectangle;
	rectangle.setSize(sf::Vector2f((float)length, (float) 0)); // Vector2f is two floats x, and y. Sets height = length, width = 0
	rectangle.setOutlineColor(color);
	rectangle.setOutlineThickness(0.5); // Value 1 gives 2 pixels line, Value 0.5 gives 1
	rectangle.setPosition((float)startX, (float)startY);
	rectangle.setRotation(direction);
	win->draw(rectangle);
	linesDrawn++; // demonstrates static variable
}

void ConsolePause() {
	string s;
	cout << "\n\n >>> Trykk enter her i konsoll-vindu for å fortsette..." << endl;
	getline(cin, s);
}
