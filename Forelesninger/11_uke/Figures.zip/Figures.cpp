#include <iostream>
#include "Figures.h"
#include <SFML/Graphics.hpp>
#include "mySFML.h"
#include <string>
#include <sstream>
using namespace std;

Figure::Figure(const string &name, sf::Color color)
	: name(name), color(color)
{ }

string Figure::getName() {
	return name;
}

//ComposedFigure::ComposedFigure(const string &name, sf::Color color)
//	: Figure(name, color) { }
ComposedFigure::ComposedFigure(const string &name)
	: Figure(name, sf::Color::White) { }

ComposedFigure::~ComposedFigure() {
	for (unsigned int i = 0; i < parts.size(); i++) {
		delete parts[i];
	}
}

void ComposedFigure::addFigure(Figure *fig) {
	parts.push_back(fig);
}

void ComposedFigure::draw(sf::RenderWindow* win) {
	for (unsigned int i = 0; i < parts.size(); i++) {
		parts[i]->draw(win);
	}
}

Rectangle::Rectangle(const string & name, sf::Color color)
	: Figure(name, color),
	  height(0),
	  width(0),
	  center(0,0)
{ }

void Rectangle::setSize(int h, int w) {
	height = h;
	width = w;
}

void Rectangle::setPos(int x, int y) {
	center.x = x;
	center.y = y;
}

string Rectangle::toString() const { // demonstrates use of to_string from <string>
	return "Rectangle: " + name + ' ' + to_string(height) + 'x' + to_string(width)
		+ " at (" + to_string(center.x) + ',' + to_string(center.y) + ")\n";
}

void Rectangle::draw(sf::RenderWindow* win) {
	sf::RectangleShape rect;
	rect.setFillColor(color);
	rect.setOutlineThickness(0); // disables the outline 
	rect.setSize(sf::Vector2f((float)width, (float)height));
	rect.setPosition((float)center.x - (width / 2), (float)center.y - (height / 2));
	win->draw(rect);
}

RectangleFrame::RectangleFrame(const string & name, sf::Color color)
	: Rectangle(name, color) { }
 
string RectangleFrame::toString() const { 
	stringstream ss; // demonstrates stringstream from <sstream>, textbook page 581 (5th ed), 587 (6th ed)
	ss.clear();
	ss << "RectangleFrame: " << name << ' ' << height << 'x' << width
		<< " at (" << center.x << ',' << center.y << ")\n";
	return ss.str();
}

void RectangleFrame::draw(sf::RenderWindow* win) {
	drawLine(width, center.x - (width / 2), center.y - (height / 2), 0, color, win);
	drawLine(height, center.x + (width / 2), center.y - (height / 2), 90, color, win);
	drawLine(width, center.x + (width / 2), center.y + (height / 2), 180, color, win);
	drawLine(height, center.x - (width / 2), center.y + (height / 2), 270, color, win);
}

Circle::Circle(const string & name, sf::Color color)
	: Figure(name, color),
	  radius(0),
	  center(0,0)
{ }

void Circle::setRadius(int r) {
	radius = r;
}

void Circle::setPos(int x, int y) {
	center.x = x; 
	center.y = y;
}

string Circle::toString() const {
	stringstream ss;
	ss.clear();
	ss << "Circle: " << name << " radius " << radius << " at ("
		<< center.x << ',' << center.y << ")\n";
	return ss.str();
}

void Circle::draw(sf::RenderWindow* win) {
	sf::CircleShape circ((float)radius);
	circ.setPosition((float)center.x, (float)center.y);
	circ.setFillColor(color); 
	win->draw(circ);
}

Line::Line(const string & name, sf::Color color)
	: Figure(name, color),
	  length(0),
	  start(0,0),
	  direction(0.0)
{ }

void Line::setPos(int x, int y) {
	start.x = x;
	start.y = y;
}

void Line::setLength(int len) { 
	length = len;
}

void Line::setDirection(float dir) {
	direction = dir;
}

string Line::toString() const {
	stringstream ss;
	ss.clear();
	ss << "Line: " << name << " starts at: (" << start.x << "," << start.y << ") length: "  
		<< length << " direction: " << direction << "\n";
	return ss.str();
}

void Line::draw(sf::RenderWindow * win) {
	drawLine(length, start.x, start.y, direction, color, win);
}
