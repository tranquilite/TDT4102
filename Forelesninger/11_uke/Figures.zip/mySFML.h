// mySFML.h    "interface" to SFML to make code look nicer 
//             focus of lecture is Figures.h and Figures.cpp
#pragma once
#include <string>
using namespace std;

enum DisplaySize {LARGE=0, MEDIUM, NUM_DS_VALUES}; // Last enum-value is actually number of display sizes

sf::RenderWindow* openWindow(DisplaySize ds, const string& displayTitle);
void drawLine(int length, int startX, int startY, float direction, sf::Color color, sf::RenderWindow* win);
void closeDown(sf::RenderWindow* wP);

// SFML predefined colors are (see file Color.hpp): Black, White, Red, Green, Blue, Yellow, Magenta, Cyan, Transparent;
 
void ConsolePause();
