#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <iostream>
#include <string>
#include "mySFML.h"
#include "Figures.h"
using namespace std;

void demoPart1(sf::RenderWindow* wP) {
	wP->clear();

	// ********* Some simple testfunctions
	//Figure f1("Figure 1", sf::Color::Green); // gives error C2259: 'Figure': cannot instantiate abstract class
	Rectangle r1("Rectangle r1", sf::Color::Green);
	r1.setSize(100, 200);
	// cout << r1.height; // Gives error C2248 : 'Rectangle::height' : cannot access protected member declared in class 'Rectangle'
	// cout << r1.name; // Gives same error, Rectangle inherits name from Figure, but can only be used inside Rectangle object such
	// as in Rectangle::toString() but not as here in main program.
	r1.setPos(300, 600);
	cout << r1.toString();
	r1.draw(wP);

	RectangleFrame r2("RectangleFrame r2", sf::Color::Yellow);
	r2.setSize(100, 200);
	r2.setPos(300, 600);
	cout << r2.toString();
	r2.draw(wP);

	Circle c1("Circle c1", sf::Color::Red);
	c1.setRadius(50);
	c1.setPos(300, 200);
	cout << c1.toString();
	c1.draw(wP);

	Circle c2("Circle c2", sf::Color::Blue); 
	c2.setRadius(50);
	c2.setPos(500, 200);
	cout << c2.toString();
	c2.draw(wP);

	Line l1("Line l1", sf::Color::Cyan);
	l1.setLength(400);
	l1.setPos(0, 0);
	l1.setDirection(45);
	cout << l1.toString();
	l1.draw(wP);
}

void drawCar(int offsetX, int offsetY, int length, int height, sf::RenderWindow *wP) {
	// offset is upper left corner
	Rectangle r1("CarBody", sf::Color::Blue);
	r1.setSize(height / 2, length);
	r1.setPos(offsetX + (length / 2), offsetY + (height * 35) / 60);
	cout << r1.toString();
	r1.draw(wP);

	RectangleFrame r2("CarTop", sf::Color::Blue);
	r2.setSize(height / 3, (length * 8) / 12);
	r2.setPos(offsetX + ((length * 8) / 12), offsetY + ((height * 1) / 6));
	cout << r2.toString();
	r2.draw(wP);

	Rectangle r3("FrontLight", sf::Color::White);
	r3.setSize(height / 6, length / 12);
	r3.setPos(offsetX + 2 + length / (12 * 2), offsetY + 2 + (height * 5) / 12);
	cout << r3.toString();
	r3.draw(wP);

	Rectangle r4("RearLight", sf::Color::Red);
	r4.setSize(height / 8, length / 16);
	r4.setPos((offsetX - 1 + (length * 23) / 24), offsetY + 2 + (height * 5) / 12);
	cout << r4.toString();
	r4.draw(wP);

	Circle c1("FrontWheel", sf::Color::Black);
	c1.setRadius(length / 12);
	c1.setPos(offsetX + (length * 2) / 12, offsetY + (height * 4) / 6);
	cout << c1.toString();
	c1.draw(wP);

	Circle c2("RearWheel", sf::Color::Black);
	c2.setRadius(length / 12);
	c2.setPos(offsetX + (length * 9) / 12, offsetY + (height * 4) / 6);
	cout << c2.toString();
	c2.draw(wP);

	Circle c3("Driver", sf::Color::Yellow);
	c3.setRadius(length / 24);
	c3.setPos(offsetX + (length * 5) / 12, offsetY + (height * 10) / 60);
	cout << c3.toString();
	c3.draw(wP);

	Line l1("Antenna", sf::Color::Magenta);
	l1.setPos(offsetX + (length * 3) / 24, offsetY + (height * 2) / 6);
	l1.setLength((height * 2) / 6);
	l1.setDirection(300);
	cout << l1.toString();
	l1.draw(wP);
}

void buildCar(int offsetX, int offsetY, int length, int height, ComposedFigure* car) {
	// offset is upper left corner
	Rectangle* r1 = new Rectangle("CarBody", sf::Color::Blue);
	r1->setSize(height / 2, length);
	r1->setPos(offsetX + (length / 2), offsetY + (height * 35) / 60);
	cout << r1->toString();
	car->addFigure(r1);

	RectangleFrame* r2 = new RectangleFrame("CarTop", sf::Color::Blue);
	r2->setSize(height / 3, (length * 8) / 12);
	r2->setPos(offsetX + ((length * 8) / 12), offsetY + ((height * 1) / 6));
	cout << r2->toString();
	car->addFigure(r2);

	Rectangle* r3 = new Rectangle("FrontLight", sf::Color::White);
	r3->setSize(height / 6, length / 12);
	r3->setPos(offsetX + 2 + length / (12 * 2), offsetY + 2 + (height * 5) / 12);
	cout << r3->toString();
	car->addFigure(r3);

	Rectangle* r4 = new Rectangle("RearLight", sf::Color::Red);
	r4->setSize(height / 8, length / 16);
	r4->setPos((offsetX - 1 + (length * 23) / 24), offsetY + 2 + (height * 5) / 12);
	cout << r4->toString();
	car->addFigure(r4);

	Circle* c1 = new Circle("FrontWheel", sf::Color::Black);
	c1->setRadius(length / 12);
	c1->setPos(offsetX + (length * 2) / 12, offsetY + (height * 4) / 6);
	cout << c1->toString();
	car->addFigure(c1);

	Circle* c2 = new Circle("RearWheel", sf::Color::Black);
	c2->setRadius(length / 12);
	c2->setPos(offsetX + (length * 9) / 12, offsetY + (height * 4) / 6);
	cout << c2->toString();
	car->addFigure(c2);

	Circle* c3 = new Circle("Driver", sf::Color::Yellow);
	c3->setRadius(length / 24);
	c3->setPos(offsetX + (length * 5) / 12, offsetY + (height * 10) / 60);
	cout << c3->toString();
	car->addFigure(c3);

	Line* l1 = new Line("Antenna", sf::Color::Magenta);
	l1->setPos(offsetX + (length * 3) / 24, offsetY + (height * 2) / 6);
	l1->setLength((height * 2) / 6);
	l1->setDirection(300);
	cout << l1->toString();
	car->addFigure(l1);
}

void demoPart2(sf::RenderWindow* wP) {
	wP->clear(sf::Color::White);

	drawCar(200, 100, 360, 180, wP);
	drawCar(200, 300, 240, 120, wP);
	drawCar(200, 500, 120, 60, wP);
}

void demoPart3(sf::RenderWindow* wP) {
	wP->clear(sf::Color::White);

	ComposedFigure* myCar1 = new ComposedFigure("Min bil nr. 1");
	buildCar(300, 400, 360, 180, myCar1); 
	myCar1->draw(wP);

	ComposedFigure* myCar2 = new ComposedFigure("Min bil nr. 2");
	buildCar(500, 600, 260, 100, myCar2); // placed at another position
	myCar2->draw(wP);

	delete myCar1;
	delete myCar2;
}

int main()
{
	setlocale(LC_ALL, "Norwegian");  // Gjør det mulig med æ, ø og å
	sf::RenderWindow *wP = openWindow(MEDIUM, "TDT-4102 Figures example");

	sf::Vector2u winSize = wP->getSize(); // Shows how to read Window size
	cout << "Windowsize: " << winSize.x << " x " << winSize.y << endl;

	// Start main event loop
	while (wP->isOpen()) { // See http://www.sfml-dev.org/tutorials/2.0/window-window.php
		sf::Event event;
		while (wP->pollEvent(event)) {
			if (event.type == sf::Event::Closed)
				wP->close();

			if (event.type == sf::Event::KeyPressed) {
				cout << "Du tastet:  " << event.key.code << endl;
				switch (event.key.code) {
					case sf::Keyboard::Num1:
						demoPart1(wP);
						wP->display();
						break;
					case sf::Keyboard::Num2:
						demoPart2(wP);
						wP->display();
						break;
					case sf::Keyboard::Num3:
						demoPart3(wP);
						wP->display();
						break;
					default:
						break;
				}
			}
		}
		//wP->display(); // gives flicker
	}
	closeDown(wP);
	return 0;
}
