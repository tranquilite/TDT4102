#pragma once
// Example inspired by Savitch 5th ed page 691 (and 699)
//							   6th ed page 699 (and 708)					
using namespace std;
#include <string>
#include <SFML/Graphics.hpp>

struct Point {
	Point(int x=0, int y=0) : x(x), y(y) { }
	int x;
	int y;
};

class Figure {
protected:
	string name; // can be accessed in subclass
	sf::Color color; // color for the figure 
public:
	Figure(const string & name, sf::Color color = sf::Color::White);
	virtual ~Figure() {}
	string getName();
	virtual void draw(sf::RenderWindow* win) = 0; // Figure is abstract class
};

class ComposedFigure : public Figure {
protected:
	vector <Figure*> parts; // vector of Figure components
public:
	ComposedFigure(const string & name);
	~ComposedFigure();
	void addFigure(Figure *fig);
	virtual void draw(sf::RenderWindow* win);
};

class Rectangle : public Figure {
protected:
	int height;
	int width;
	Point center;
public:
	Rectangle(const string &name, sf::Color color);
	void setSize(int h, int w);
	void setPos(int x, int y);
	string toString() const;
	virtual void draw(sf::RenderWindow* win);	
};

class RectangleFrame : public Rectangle {
public:
	RectangleFrame(const string &name, sf::Color color);
	string toString() const;
	void draw(sf::RenderWindow* win); 
};

class Circle : public Figure {
private:
	int radius;
	Point center;
public:
	Circle(const string &name, sf::Color color);
	void setRadius(int r);
	void setPos(int x, int y);
	string toString() const;
	void draw(sf::RenderWindow* win);
};

class Line : public Figure {
private:
	int length;
	Point start;
	float direction;
public:
	Line(const string &name, sf::Color color);
	void setPos(int x, int y);
	void setLength(int len);
	void setDirection(float dir);
	string toString() const;
	void draw(sf::RenderWindow* win);
};


