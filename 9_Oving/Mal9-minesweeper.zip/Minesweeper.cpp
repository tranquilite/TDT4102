#include "Minesweeper.h"

Minesweeper::Minesweeper(int width, int height, int mines) {

}

Minesweeper::~Minesweeper() {

}

bool Minesweeper::isGameOver() const {
    return false;
}

bool Minesweeper::isTileOpen(int row, int col) const {
    return false;
}

bool Minesweeper::isTileMine(int row, int col) const {
    return false;
}

void Minesweeper::openTile(int row, int col) {

}

int Minesweeper::numAdjacentMines(int row, int col) const {
    return 0;
}
